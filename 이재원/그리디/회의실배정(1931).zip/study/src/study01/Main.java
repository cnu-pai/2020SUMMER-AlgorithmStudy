package study01;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int time = 0;
		int count = 0;
		int n = sc.nextInt();
		
		int[][] arr =new int[n][2];
		
		for(int i =0; i<n; i++) {
			arr[i][0] = sc.nextInt();
			arr[i][1] = sc.nextInt();
		}
		
		Arrays.sort(arr, new Comparator<int[]>() {
			@Override
			
			public int compare(int[] arg0, int[] arg1) {
				if(arg0[1]==arg1[1]) {
					return Integer.compare(arg0[0], arg1[0]);
				}
				return Integer.compare(arg0[1], arg1[1]);
			}
						
		});
		
		for(int i =0; i<n; i++) {
			if(arr[i][0] >= time) {
				count++;
				time = arr[i][1];
			}
		}
	
		sc.close();
		System.out.println(count);
	}
	

}
