package study01;

import java.util.*;

public class Dan99 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		

		int n = sc.nextInt();
		int m = sc.nextInt();
		
		int[] a = new int[m];
		
		dfs(a,0,n);

}
	public static boolean real(int[] arr,int s, int k ) {
		for(int i = 0; i<k;i ++) {
			if(arr[i] == s)
				return true;
		}
		return false;
	}
	
	public static void dfs(int a[], int i, int n) {
		if(a.length == i ) {
			for(int j = 0; j<a.length; j++) {
				System.out.print(a[j]+" ");
			}
			System.out.println("");
		}
		else {
			for(int j = 1; j<=n; j++) {
				if(!real(a,j,i)) {
					a[i] = j;
					dfs(a,i+1,n);
				}
			}
		}
	}
}