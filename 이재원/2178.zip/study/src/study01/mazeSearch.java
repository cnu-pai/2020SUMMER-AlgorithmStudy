package study01;

import java.util.*;
import java.io.*;

class dot{
	int _x, _y;
	dot(int x, int y){
		this._x = x;
		this._y = y;
	}
}





public class mazeSearch {
	public static final int[] dx = {0,0,1,-1};
	public static final int[] dy = {1,-1,0,0};

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int m = sc.nextInt();
		int[][] map = new int[n][m];
		sc.nextLine();
		for(int i = 0; i <n;i++) {
			String o = sc.nextLine();
			for(int j =0; j<m;j++) {
				map[i][j] = o.charAt(j) -'0';
			}
		}
		
		int[][] call= new int [n][m];
		boolean[][] visit = new boolean[n][m];
		Queue<dot> q = new LinkedList<dot>();
		q.add(new dot(0,0));
		visit[0][0] = true;
		call[0][0] = 1;
		while(!q.isEmpty()) {
			dot d = q.remove();
			int x = d._x;
			int y = d._y;
			for(int k = 0; k<4; k++) {
				int nx = x+dx[k];
				int ny = y+dy[k];
				if(nx>=0 && nx<n && ny>=0 && ny <m) {
					if(visit[nx][ny] == false &&map[nx][ny] ==1) {						
					q.add(new dot(nx,ny));
					call[nx][ny] = call[x][y]+1;
				visit[nx][ny] = true;
				}
			}

		}

				
	}

	System.out.println(call[n-1][m-1]);
}
}